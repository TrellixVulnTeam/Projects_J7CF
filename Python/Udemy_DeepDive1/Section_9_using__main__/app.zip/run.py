print(f'loading run.py: __name__ = {__name__}')

import module1